
"use client";

// MUI Components Used:
// Drawer, Box, Typography, List, ListItemButton
import {
  Drawer,
  Box,
  Typography,
  List,
  ListItemButton,
  ListItemText
} from "@mui/material";

const items = ["Home", "Focus AI", "Study", "Profile", "Settings"];

export default function Sidebar({ open, onClose, currentTab, setCurrentTab }) {
  return (
    <Drawer open={open} onClose={onClose}>
      <Box sx={{ width: 260, p: 3, bgcolor: "#0d1025", color: "white", height: "100%" }}>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          FOCUS+
        </Typography>

        <List>
          {items.map((item) => (
            <ListItemButton
              key={item}
              onClick={() => {
                setCurrentTab(item);
                onClose();
              }}
              sx={{
                borderRadius: 3,
                mb: 1,
                bgcolor: currentTab === item ? "#2a2d52" : "transparent"
              }}
            >
              <ListItemText primary={item} />
            </ListItemButton>
          ))}
        </List>
      </Box>
    </Drawer>
  );
}
