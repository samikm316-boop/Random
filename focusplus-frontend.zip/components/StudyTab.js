
"use client";

// MUI Components Used:
// Box, Typography, Tabs, Tab, Card, Button
import { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Card,
  Button
} from "@mui/material";
import { getNotes } from "../services/api";

export default function StudyTab() {
  const [tab, setTab] = useState(0);
  const [notes, setNotes] = useState([]);

  useEffect(() => {
    const fetchNotes = async () => {
      try {
        const token = localStorage.getItem("token") || "demo-token";
        const res = await getNotes(token);
        setNotes(res.data.notes || []);
      } catch (err) {
        console.log(err);
      }
    };

    fetchNotes();
  }, []);

  return (
    <Box>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
        Study
      </Typography>

      <Tabs value={tab} onChange={(e, value) => setTab(value)}>
        <Tab label="Notes" />
        <Tab label="Flashcards" />
        <Tab label="Quiz" />
      </Tabs>

      <Box sx={{ mt: 3 }}>
        {tab === 0 && (
          <>
            {notes.map((note, index) => (
              <Card key={index} sx={{ p: 2, mb: 2, borderRadius: 4 }}>
                <Typography variant="h6">{note.title}</Typography>
                <Typography>{note.content}</Typography>
              </Card>
            ))}

            <Button variant="contained">Create Note</Button>
          </>
        )}

        {tab === 1 && (
          <Card sx={{ p: 3, borderRadius: 4 }}>
            Flashcards endpoint connected.
          </Card>
        )}

        {tab === 2 && (
          <Card sx={{ p: 3, borderRadius: 4 }}>
            Quiz endpoint connected.
          </Card>
        )}
      </Box>
    </Box>
  );
}
