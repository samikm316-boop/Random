
"use client";

// MUI Components Used:
// Box, Typography, TextField, Button, Paper
import { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  Paper
} from "@mui/material";

import { sendMessage } from "../services/api";

export default function AITab() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (!input) return;

    const token = localStorage.getItem("token") || "demo-token";

    const userMessage = {
      role: "user",
      content: input
    };

    setMessages((prev) => [...prev, userMessage]);

    try {
      const res = await sendMessage(token, {
        message: input,
        type: "study"
      });

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: res.data.reply || "AI Response"
        }
      ]);
    } catch (err) {
      console.log(err);
    }

    setInput("");
  };

  return (
    <Box>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
        Focus AI
      </Typography>

      <Box sx={{ height: 400, overflowY: "auto", mb: 2 }}>
        {messages.map((msg, index) => (
          <Paper
            key={index}
            sx={{
              p: 2,
              mb: 2,
              borderRadius: 4,
              ml: msg.role === "assistant" ? 0 : "auto",
              maxWidth: "70%",
              bgcolor: msg.role === "assistant" ? "white" : "#7c4dff",
              color: msg.role === "assistant" ? "black" : "white"
            }}
          >
            {msg.content}
          </Paper>
        ))}
      </Box>

      <Box sx={{ display: "flex", gap: 2 }}>
        <TextField
          fullWidth
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask anything..."
        />

        <Button variant="contained" onClick={handleSend}>
          Send
        </Button>
      </Box>
    </Box>
  );
}
