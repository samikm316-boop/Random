
"use client";

// MUI Components Used:
// Box, Typography, Card, LinearProgress, Button
import { Box, Typography, Card, LinearProgress, Button } from "@mui/material";

export default function HomeTab() {
  return (
    <Box>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
        Welcome Back
      </Typography>

      <Card sx={{ p: 3, borderRadius: 5, mb: 3 }}>
        <Typography variant="h5">USER</Typography>
        <Typography sx={{ mb: 2 }}>Level 3</Typography>

        <LinearProgress
          variant="determinate"
          value={60}
          sx={{
            height: 10,
            borderRadius: 10,
            mb: 2
          }}
        />

        <Button variant="contained">Continue Learning</Button>
      </Card>
    </Box>
  );
}
