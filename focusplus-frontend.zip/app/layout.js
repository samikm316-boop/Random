
export const metadata = {
  title: "Focus+",
  description: "Study Dashboard UI"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, background: "#f4f5fb", fontFamily: "sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
