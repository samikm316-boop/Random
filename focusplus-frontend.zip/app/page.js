
"use client";

// MUI Components Used:
// Box, IconButton, Container
import { useState } from "react";
import { Box, IconButton, Container } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";

import Sidebar from "../components/Sidebar";
import HomeTab from "../components/HomeTab";
import StudyTab from "../components/StudyTab";
import AITab from "../components/AITab";

export default function Page() {
  const [open, setOpen] = useState(false);
  const [currentTab, setCurrentTab] = useState("Home");

  const renderContent = () => {
    switch (currentTab) {
      case "Focus AI":
        return <AITab />;

      case "Study":
        return <StudyTab />;

      default:
        return <HomeTab />;
    }
  };

  return (
    <Container maxWidth="sm" sx={{ py: 3 }}>
      <Sidebar
        open={open}
        onClose={() => setOpen(false)}
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
      />

      <Box
        sx={{
          bgcolor: "white",
          minHeight: "100vh",
          borderRadius: 8,
          p: 3,
          boxShadow: "0 10px 30px rgba(0,0,0,0.08)"
        }}
      >
        <IconButton onClick={() => setOpen(true)}>
          <MenuIcon />
        </IconButton>

        {renderContent()}
      </Box>
    </Container>
  );
}
