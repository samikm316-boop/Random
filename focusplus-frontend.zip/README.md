
# Focus+ Frontend

## Stack
- Next.js 14
- React 18
- Material UI (MUI)
- Axios

## Features
- Sidebar Navigation
- Tabs Layout
- AI Chat Screen
- Study Notes Screen
- API Integration
- Mobile First UI

## Install

```bash
npm install
npm run dev
```

## API URL

Create `.env.local`

```env
NEXT_PUBLIC_API_URL=http://localhost:5000
```
