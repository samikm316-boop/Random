
// Axios API service
// Third-party library: axios
import axios from "axios";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"
});

export const getCurrentUser = async (token) => {
  return api.get("/users/me", {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const getNotes = async (token) => {
  return api.get("/study/notes", {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const sendMessage = async (token, payload) => {
  return api.post("/chat", payload, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export default api;
